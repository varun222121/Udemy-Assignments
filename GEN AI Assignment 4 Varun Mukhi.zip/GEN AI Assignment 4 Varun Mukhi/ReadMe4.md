# Assignment 4
This is assignment 4 of generative ai devlopment course.
The file contains 7 python programing problems (tasks). Each task is different from the other.
Tasks are labeled and titled above the python program.

# How to run the program

# Environment & Requirements

Operating System:** Windows
Python Version:** 3.13.9
Required Tools:** Jupyter Notebook / JupyterLab

Kernel Needed to run the program
(venv(python3.13.9))

# Codes instruction
Task 1: Aims to create a .txt file and write the sales ammount in it
        The entier proble is done in 3 code cell
        cell 1. Creates the file and writes in the file
        cell 2. Appends more data in the filel
        cell 3. Reads and shows the data
        code does not need any user input to execute.
Task 2: Aims to read the  .txt file in different ways
        The Entire problem is done in 3 different code cells
        Cell 1: Opens and read the file (sales_data.txt)
        Cell 2: Opens and read only first line of file (sales_data.txt)
        Cell 3: Opens and read all lines of the file and convert the numbers into 
                integers and add them into a list
Task 3: Adds new data ino the same file (sales_data.txt)
        The problem is done in 2 different code cells
        Cell 1: Appends new data into the file
        Cell 2: Reads and print all the data with newly added once
Task 4: Aims to give sumarry report of the file sales_data.txt
        The problem is done in code cell
        Cell 1: creates a new list add all the data of the file into it
                converts them into integers
                Shows its Highest sales value
                Shows its minimum sales value
                calculate its average of total sales 
                calculates its total sales
Task 5: Aim to create a product list by taking minimum 3 product details
        The entire problem is done in 3 coe cells
        Cell 1: Take 3 product inputs and adds it to in dictionary
                Product 1
                {input(1): input product name
                input(2): input product price}
                Product 2
                {input(1): input product name
                input(2): input product price}
                Product 3
                {input(1): input product name
                input(2): input product price}
            Prints the dictionary
        Cell 2: Open the file (product.txt) and writes all the data of the 
                dictionary into it print 'done' after successfylly adding all the data in( product | price ) format
        Cell 3: Prints all the data of file (product.txt) in different lines.
Task 6: Aims to take user input of file names and open it
        The entier code is done in one code cell
        Cell 1: Asks user input of file name reads it data and opens the file data in the terminal. 
        If file name in wrong it throws Error message
        (Acepted and present file names.
        1.discount_report.txt
        2.product.txt
        3.sales_data.txt)
Task 7: Aims to take user input of discount in percentage and 
        Calculate discount price of each product given in the given list
        Entire program is done in 2 code cells
        Cell 1: Takes user input of discount in percentage opens file
                calculates each item discount and writes the data into
                the file (discount_report.txt) in 
                'product | price | discount price' format.
        Cell 2: Reads the file (discount_price.txt) and shows its data
            